﻿namespace Gestão_de_equipamentos
{
    public class Equipamento
    {
        public int id;
        public string nome;
        public decimal preco;
        public string fabricante;
        public string serie;
        public DateTime dataFabricacao;

    }
}
